TRACTRAC v1.5 (6/02/2017) for Python
# Notes of versions
# v1.5 _________________________________________________________________________________
# Possibility to execute tractrac both as a module (import tractrac) or directly in bash (python tractrac.py)
# Integration of non-constant times step
# Possibility to read an "interpolated" motion model image of U and V
# Parameter file now called *_par.txt
# Fixed some difference between Matlab and Python version, some diff remain notably in the error thresholds

Installation___________________________________________________________
1. Unzip in a folder
2. Requirement:  Python 2.7, Opencv2 or higher and the following packages installed:
numpy
scipy
cv2 (OpenCV 2.0-3.0-...)
pyplot 
matplotlib
parse
multiprocessing
imutils
argparse

You can install them simply with pip in Ubuntu : > sudo pip install package_name 


> Run from command line ___________________________________________________

1. Run simply with >> python tractrac.pyc
2. or provide advanced options (help file: >> python tractrac.py -h) :
  -h, --help            show this help message and exit
  -f FILE, --file FILE  Video Filename to track
  -tf FILE, --tfile FILE Filename of frame time stamp 
  -o, --output          Save tracking results in a file
  -s, --silent          No tracking infos
  -p, --plot            Live plot of tracking results
  -sp, --saveplot       Save plots in image sequence
  -cmin CMIN, --cmin CMIN
                        Minimum velocity (px/frame) for plotting
  -cmax CMAX, --cmax CMAX
                        Maximum velocity (px/frame) for plotting
  -ca CALPHA, --calpha CALPHA
                        Alpha value for arrows

> Run from python script ___________________________________________________

import tractrac as tt # Import tractrac module into python 
Pts,th= tt.run() # Run on sample file

# Detail of Function run()

# Optional input arguments are :
# 	f=videofilename (string) : Pathname of the video file to analyse.
# 	tf=time_filename (string) : Pathname of the time stamp of video frames.
# 	th=[{}] (Dictionnary list) : Tracking parameters (as in parameter file)
# 	p=plotting_option (0,1,2,3): for no plot, normal plot, motion model plot, or motion model error plot.
# 	o=output_file (0,1) : save the tracking results in a file of name videofilename_track.txt.
# 	s=silent (0,1) : verbose or silent computation.
# 	sp=save_plot (0,1) : Save images of each plots.
# 	clim=(float,float) : caxis color limits for plotting.
# 	alpha=float : Transparency of plotting

# Output arguments are:
# Pts (np.array) : Result array of tracklets. Columns are in order : 0 Frame, 1 Track ID, 2 X, 3 Y, 4 U, 5 V, 6 U motion model, 7 V motion model, 8 X Acceleration, 9 Y acceleration, 10 Motion model error
# th (list dictionnary) : Tracking parameters

# Example :
import tractrac as tt
th=[{}]
th[0]['nlin']=2
th[0]['ncol']=2
th[0]['peak_th_auto']=0
th[0]['peak_th']=0.1
Pts,th = tt.run(th=th,s=0,p=1)


Enjoy !
Joris 2017

